package partiepratique;

    
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author vicwa
 */

public class Connect extends JFrame implements ActionListener {

    private JFrame f;
    private JPanel panel1, panel2, panel3 ;
    private JLabel jl, text, image, nom, mdp;
    private JTextField user;
    private JPasswordField pwd;
    private JButton ok, cancel;

    public Connect() {

        JFrame f = new JFrame();
        this.setSize(1000, 600);
        this.setResizable(false);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setTitle("Sécurité de Windows");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        panel1 = new JPanel();
        panel1.setBounds(0, 0, 1000, 90);
        panel1.setLayout(null);
        panel1.setBackground(Color.lightGray);
        this.add(panel1);

        panel2 = new JPanel();
        panel2.setBounds(0, 90, 1000, 320);
        panel2.setLayout(null);
        panel2.setBackground(Color.gray);
        this.add(panel2);

        panel3 = new JPanel();
        panel3.setBounds(0, 410, 1000, 600);
        panel3.setLayout(null);
        panel3.setBackground(new Color(100, 100, 100));
        this.add(panel3);


        jl = new JLabel();
        jl.setText("Authentification réseau");
        jl.setLayout(null);
        jl.setForeground(new Color(255, 0, 0));
        jl.setBounds(10,5, 1000, 30);
        jl.setVerticalTextPosition(SwingConstants.BOTTOM);
        jl.setHorizontalTextPosition(SwingConstants.CENTER);
        panel1.add(jl);

        text = new JLabel();
        text.setText("Veuillez entrer les informations d'identification utilisateur");
        text.setLayout(null);
        text.setBounds(10,25, 1000, 50);
        text.setFont(new Font("Arial", Font.PLAIN, 12));
        text.setVerticalTextPosition(SwingConstants.TOP);
        text.setHorizontalTextPosition(SwingConstants.CENTER);
        panel1.add(text);

        String fifi = "C:\\Users\\vicwa\\Desktop\\Pratique\\PartiePratique\\src\\partiepratique\\fifi.jpg";
        image = new JLabel(new ImageIcon(fifi));
        image.setLayout(null);
        image.setBounds(0,0,350,320);
        panel2.add(image);

        nom = new JLabel();
        nom.setText("Nom d'utilisateur : ");
        nom.setBounds(525,145,200,25);
        panel2.add(nom);

        mdp = new JLabel();
        mdp.setText("Mot de passe : ");
        mdp.setBounds(525,200,200,25);
        panel2.add(mdp);

        user = new JTextField();
        user.setBounds(650,145,240, 25);
        user.addActionListener(this);
        panel2.add(user);

        pwd = new JPasswordField();
        pwd.setBounds(650,200,240, 25);
        pwd.addActionListener(this);
        panel2.add(pwd);

        ok = new JButton("nice");
        ok.setText("Connecter");
        ok.addActionListener(this);
        ok.setBounds(650,75,100,30);
        panel3.add(ok);

        cancel = new JButton("sayonara");
        cancel.setText("Annuler");
        cancel.setBounds(810,75,100,30);
        cancel.addActionListener(this);
        panel3.add(cancel);

    }

    @Override
    public void actionPerformed(ActionEvent evt) {

        if (evt.getSource() == ok) {
            Modele mod = new Modele();
            String log = user.getText();
            String motpasse = String.valueOf(pwd.getPassword());
            String req = "SELECT count(*) FROM `user` WHERE login = '"+log+"' AND password = '"+motpasse+"';";
            System.out.println(req);
            try { 
                if (mod.verifLogin(req) == 1 ) {
                    Menu test = new Menu();
                    test.setVisible(true);
                    this.setVisible(false);
                }
                
                else {
                    JOptionPane.showMessageDialog(null, "Erreur login");
                    user.setText("");
                    pwd.setText("");
                    pwd.setBackground(Color.white);
                    user.requestFocus();
                    
                }
                
            }
            
            catch (Exception e) {
                e.getMessage();
            }
            
            
        }
        else if (evt.getSource() == cancel)
            System.exit(0);
    }


}
